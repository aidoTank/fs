﻿//#region Assembly System.dll, v2.0.0.0
//// C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.dll
//#endregion

//#if UNITY_METRO && !UNITY_EDITOR
//using System;

//namespace System.Net
//{
//	// Summary:
//	//     Represents the method that will handle the System.Net.WebClient.OpenReadCompleted
//	//     event of a System.Net.WebClient.
//	//
//	// Parameters:
//	//   sender:
//	//     The source of the event.
//	//
//	//   e:
//	//     A System.Net.OpenReadCompletedEventArgs containing event data.
//	public delegate void OpenReadCompletedEventHandler(object sender, OpenReadCompletedEventArgs e);
//}
//#endif