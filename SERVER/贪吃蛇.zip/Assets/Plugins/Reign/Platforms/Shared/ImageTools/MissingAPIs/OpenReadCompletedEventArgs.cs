﻿//#region Assembly System.dll, v2.0.0.0
//// C:\Windows\Microsoft.NET\Framework\v2.0.50727\System.dll
//#endregion

//#if UNITY_METRO && !UNITY_EDITOR
//using System.ComponentModel;
//using System.IO;

//namespace System.Net
//{
//	// Summary:
//	//     Provides data for the System.Net.WebClient.OpenReadCompleted event.
//	public class OpenReadCompletedEventArgs : AsyncCompletedEventArgs
//	{
//		// Summary:
//		//     Gets a readable stream that contains data downloaded by a Overload:System.Net.WebClient.DownloadDataAsync
//		//     method.
//		//
//		// Returns:
//		//     A System.IO.Stream that contains the downloaded data.
//		public Stream Result { get; private set; }
//	}
//}
//#endif