// EasyJoystick v2.0 (April 2013)
// EasyJoystick library is copyright (c) of Hedgehog Team
// Please send feedback or bug reports to the.hedgehog.team@gmail.com

#pragma strict

/*
function On_JoystickDoubleTap (move: MovingJoystick){}

function On_JoystickTap (move: MovingJoystick){}

function On_JoystickTouchUp (move: MovingJoystick){}
		
function On_JoystickMoveEnd (move: MovingJoystick){}

function On_JoystickMove(move: MovingJoystick){}

function On_JoystickMoveStart (move: MovingJoystick){}

function On_JoystickTouchStart (move: MovingJoystick){}
*/
